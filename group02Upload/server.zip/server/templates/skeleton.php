<?php require_once( 'templates/header.php' );
echo $data;
require_once( 'templates/footer.php' ); ?>
