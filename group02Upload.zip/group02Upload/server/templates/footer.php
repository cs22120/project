</div>
<div id="footer">
    <div class="container">
      <p class="text-muted">
        &copy; 2014 <a href="?credits">contributors</a></p>
      </p>
    </div>
</div>
</body>
</html>
