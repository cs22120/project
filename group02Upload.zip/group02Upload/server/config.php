<?php
$DB_ADDR = 'db.dcs.aber.ac.uk';
$DB_PASS = '4dmc5gp02';
$DB_USER = 'admcsgp02';
$DB_NAME = 'csgp02_13_14';
?>