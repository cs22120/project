<?php
/**
 * This file is temporarily here for development purposes.
 * It can be used to simulate uploads without the Android client.
 *
 * @file
 */

define( 'ENTRYPOINT', true );
require 'includes/templates.php';
render( 'uploadform' );
?>
