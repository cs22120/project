<?php
/**
 * This file is here to prevent users accessing any +Indexes
 *
 * @file
 */
header( 'HTTP/1.1 301 Moved Permanently' );
header( 'Location: ../' );
?>
