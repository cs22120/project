<?php include 'header.php'; ?>
<div class="page-header">
  <h1>Installation</h1>
</div>
<p class="lead">A configuration file already exists. To run the wizard again, delete <code>config.php</code>.</p>
<p>If you need to, you can attempt to run the table installation again.</p>
<form class="form-horizontal" method="post" action="">
    <div class="form-group">
        <div class="col-sm-offset-3 col-sm-3">
           <button type="submit" class="btn btn-primary">Attempt to install tables</button>
        </div>
    </div>
</form>
